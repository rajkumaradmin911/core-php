<?php

/*Include the SNS library*/
require './vendor/autoload.php';
error_reporting(E_ALL);
ini_set("display_errors", 1);

/*Set the keys and region*/
$access_key = 'AKIAJJ3VYKXSPKGMWBXQ';
$secret_key = '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';
$region = 'ap-southeast-1';

$params = array(
    'credentials' => array(
        'key' => $access_key,     // Access Key ID 
        'secret' => $secret_key, //  Secret Access Key
    ),
    'region' => $region, // < your aws from SNS Topic region
    'version' => 'latest'
);
$sns = new \Aws\Sns\SnsClient($params); // Configure the sns service

/*User details*/
$sender_id = "TSTYOU";
$number = "+91-7828519944";
$message = "Hi!,Your otp is FRG6956 valid for 2 minutes only !!!";
$message_type = "Transactional";

/*Set the data for sms*/
$args = array(
      'MessageAttributes' => [
          'AWS.SNS.SMS.SenderID' => [
               'DataType' => 'String',
               'StringValue' => $sender_id
        ]
     ],
      "SMSType" => $message_type,
      "PhoneNumber" => $number,
      "Message" => $message
);
$result = $sns->publish($args); // Send Sms

if($result){
    echo "Message send successfully !!!";
}else{
    echo "Message Not Send";
}
?>

<!-- 9229569628 -->